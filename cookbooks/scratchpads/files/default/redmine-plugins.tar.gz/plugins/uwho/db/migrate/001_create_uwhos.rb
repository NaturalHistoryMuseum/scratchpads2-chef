class CreateUwhos < ActiveRecord::Migration
  def change
    create_table :uwhos do |t|
      t.string :guid
      t.integer :uid
      t.text :data
    end
    add_index :uwhos, :guid, :unique => true
  end
end
