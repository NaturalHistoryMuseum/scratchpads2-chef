<?php header('Location: scratchpads.eu');
