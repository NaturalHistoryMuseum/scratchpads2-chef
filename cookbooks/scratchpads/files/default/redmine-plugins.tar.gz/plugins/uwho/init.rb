Redmine::Plugin.register :uwho do
  name 'Uwho single login authentication'
  author 'Alice Heaton'
  description 'This enables single login from users of Scratchpads sites'
  version '0.0.1'

  settings(:partial => 'settings/uwho_settings',
    'default' => {
      'project_roles' => {},
      'group' => '0'
  })

  permission :uwho, {:uwho => [:uwho]}, :public => true
end
