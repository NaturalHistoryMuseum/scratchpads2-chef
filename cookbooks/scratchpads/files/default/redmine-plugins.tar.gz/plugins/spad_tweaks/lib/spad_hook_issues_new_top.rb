class SpadHookIssueNewTop < Redmine::Hook::ViewListener
  def view_issues_new_top(context = {})
    #Rails.logger.error('ININ')
    #if context[:project].id != 4 # Spad2 >> Support
    #  # Find if this user has roles 3 (manager), 4 (developer) or 5 (reporter)
    #  # for this project
    #  roles = Role.find_by_sql("SELECT roles.* FROM roles
    #  INNER JOIN member_roles ON member_roles.role_id = roles.id
    #  INNER JOIN members ON members.id = member_roles.member_id
    #  WHERE members.user_id = #{User.current.id}
    #   AND  members.project_id = #{context[:project].id}
    #   AND roles.id IN (3,4,5)
    #  ")
    #  if roles.length == 0
    #    redirect_to "/projects/spad2_support/issues/new"
    #  end
    #end
  end
end
