# Redmine User Issues

Shows the assigned issues on the user page

## Notes

Tested on Redmine 1.4.4 and 2.0.3

## Screenshot

![Screenshot](https://github.com/klausmeyer/redmine_user_issues/raw/master/readme_screenshot.png)

## Licence

This script is published under the GPLv2 licence.
