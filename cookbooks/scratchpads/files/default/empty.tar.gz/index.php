<?php echo date('c');
