class Uwho < ActiveRecord::Base
  unloadable
end
