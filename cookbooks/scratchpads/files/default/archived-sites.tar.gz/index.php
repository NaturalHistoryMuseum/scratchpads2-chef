<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>Archived!</title>
  <link type="text/css" rel="stylesheet" media="all" href="/style.css">
  <link href="http://fonts.googleapis.com/css?family=Gudea:400,700" rel="stylesheet" type"text/css">
</head>
<body>
  <div id="header">
    <a href="http://scratchpads.eu/"><img src="/scratchy_logo.png" alt="Scratchpad logo"></a>
  </div>
  <div id="content">
    <h1>Archived!</h1>
    <p>This site has been archived and is no longer being updated.  The page you are looking for is not present in the archive.</p>
  </div>
</body>
</html>
