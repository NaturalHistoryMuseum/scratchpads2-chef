class SpadHookLayoutsContent < Redmine::Hook::ViewListener
  render_on :view_layouts_base_sidebar,
            :partial => 'hooks/view_layouts_base_content'
end 
