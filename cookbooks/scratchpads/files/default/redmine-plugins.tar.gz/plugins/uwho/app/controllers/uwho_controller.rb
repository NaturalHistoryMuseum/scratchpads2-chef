require 'openssl'
require 'cgi'
require 'base64'
require 'json'
require 'shellwords'

require_relative 'pbkdf2.rb'

class UwhoController < ApplicationController
  unloadable

  KEY = "58d972f86f9d963837bebcd8d4b46d39"
  KEY_LENGTH = 32
  HASH_FUNCTION = :sha256
  CIPHER = 'aes-256-ctr'
  ITERATIONS = 1000
  PATH = "uwho"

  # We expect:
  # post: uwhodata (encrypted data)
  # get: redirect (the destination after authentication)
  def uwho
    # Validate
    if (!params.has_key?(:uwhodata))
      @message = "Request did not contain any data"
      return
    end

    # Settings
    url = "#{request.protocol}#{request.host_with_port}/" + UwhoController::PATH
    logger.debug('url:' + url)

    # Read input
    if params.has_key?(:redirect)
      destination = params[:redirect]
    else
      destination = "#{request.protocol}#{request.host_with_port}/projects/scratchpads2/issues"
    end

    encrypted_data = Base64.decode64(CGI::unescape(params[:uwhodata]))
    
    # Decrypt
    pbkdf2_key = pbkdf2(UwhoController::KEY, UwhoController::KEY + url)
    decrypted_data = decrypt(pbkdf2_key, encrypted_data)

    logger.debug('decrypted data:' + decrypted_data)
    # Desirialize
    data = unserialize(decrypted_data) 

    # Find or create the user
    user = find_or_create(data) 
    if !user.nil?
      logout_user
      self.logged_user = user

      redirect_to destination
    else
      @message = "Failed login"
    end
  end

  # Find or create a user from uwho data
  def find_or_create(data)
    user = nil
    uwho = Uwho.find_by_guid(data['guid'])
    if uwho.nil?
      logger.debug 'didn\'t find uwho entry'
      settings = Setting['plugin_uwho']

      # Create unique login
      login = data['user']['name'].downcase.gsub(/[^a-z0-9]+/, '')
      exists = User.find_by_login(login)
      c = 0
      while (!exists.nil?) do
        c = c + 1
        exists = User.find_by_login(login + c.to_s)
      end
      login = login + c.to_s if c > 0
      logger.debug('Generated login ' + login.inspect)
      # Create the user
      user = User.new

      name = data['user']['name'].split(' ')
      if (name.length == 1)
        user.firstname = name
        user.lastname = name
      else
        user.firstname = name[0,name.length-1].join(' ')
        user.lastname = name[name.length-1]
      end
      user.login = login
      password = (0..12).map{('a'..'z').to_a[rand(26)]}.join
      logger.debug "Generated password " + password.inspect
      logger.debug "x1"
      user.password = password
      user.password_confirmation = password
      user.mail = data['user']['mail']

      if user.valid?
        logger.debug 'created user is valid, saving'
        user.save
        # Add to group
        if (settings.has_key?('group') && settings['group'].to_i > 0)
          group = Group.find_by_id(settings['group'].to_i)
          if !group.nil?
            user.groups << group
          end
        end

        # Add to projects
        if (settings.has_key?('project_roles'))
          settings['project_roles'].each do |pid, rid|
            next if rid.to_i == 0

            member = Member.new
            member.user = user
            member.project = Project.find_by_id(pid.to_i)
            member.role_ids = [rid.to_i]
            member.save
          end
        end

        # Insert uwho entry
        Uwho.create({
          'guid' => data['guid'],
          'uid' => user.id,
          'data' => JSON.generate(data)
        })
      else
        logger.debug 'created user is not valid'
        logger.debug user.inspect
        user = nil
      end
    else
      logger.debug "found user in uwho record"
      user = User.find(uwho.uid)
      if user.nil?
        # It seems the user was deleted. Re-create it.
        # (this could be a guid mismatch - little we can do about that)
        logger.debug "could not find user from uwho record"
        uwho.destroy
        find_or_create(data)
      else
        logger.debug "found user from uwho record"
      end
    end
    user
  end

  # Generate raw PBKDF2 from password and salt
  def pbkdf2(password, salt)
    pbkdf2 = PBKDF2.new do |p|
      p.password = password
      p.salt = salt
      p.iterations = UwhoController::ITERATIONS
      p.hash_function = UwhoController::HASH_FUNCTION
      p.key_length = UwhoController::KEY_LENGTH
    end
    pbkdf2.value
  end

  # Decrypt data
  def decrypt(key, data)
    # Prepare data for decryption
    iv = data[0,32]
    message_mac = data[data.length-32,32]
    message = data[32, data.length - 64]

    mac = pbkdf2(iv + message, key)

    raise "wrong mac" if mac != message_mac   

    decipher = OpenSSL::Cipher.new(UwhoController::CIPHER)
    decipher.decrypt
    decipher.key = key
    decipher.iv = iv

    (decipher.update(message) + decipher.final)
  end

  # Desrialize PHP data
  def unserialize(data)
    php_code = "echo json_encode(unserialize('" + data + "'));"
    json = `php -r #{Shellwords.escape(php_code)}`
    JSON.parse(json)
  end

end



