require_dependency 'spad_hook_layouts_content'
require_dependency 'spad_hook_issues_new_top'
Redmine::Plugin.register :spad_tweaks do
  name 'Spad Tweaks plugin'
  author 'Alice Heaton'
  description 'Various tweaks specific to the Scrathcpads environment'
  version '0.0.1'
end
