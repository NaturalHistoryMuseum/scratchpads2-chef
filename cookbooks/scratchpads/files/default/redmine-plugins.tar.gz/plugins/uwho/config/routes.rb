# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html
get 'uwho', :to => 'uwho#uwho'
post 'uwho', :to => 'uwho#uwho'
