(function ($) {
  /*
   * Monitor an element matches a description
   */
  function monitor(src, match, change) {
    setInterval(function() {
      if (!$(src).is(match)) {
        console.log(src + " changed");
        change($(src));
      }
   }, 500);
  }

  /*
   * Tweaks for the issue list page
   */
  function theme_issue_list() {
    $('table.issues tr.issue td.due_date').each(function() {
      var dateString = $.trim($(this).html());
      if (dateString == '') {
        $(this).css('background', '#FF8684');
      } else {
        var dateParts = $(this).html().split("/");
        var date = new Date();
        date.setFullYear(parseInt(dateParts[2], 10), parseInt(dateParts[0], 10) - 1, parseInt(dateParts[1], 10));
        date.setHours(0,0,0,0);
        date = date.getTime();

        var today = new Date();
        today.setHours(0,0,0,0);
        today = today.getTime();

        if (date == today) {
          $(this).css('background', '#93B8FF');
        }
        if (date < today) {
          $(this).css('background', '#FF8684');
        }
      }
    });
  }

  /*
   * Tweaks for the login page
   */
  function theme_login_page() {
      var select = $('<select><option value="">--</option><option value="http://vbrant.eu/users/alice-heaton/openid">Alice Heaton (http://vbrant.eu/users/alice-heaton/openid)</option><option value="http://vbrant.eu/user/57/identity">Ben Scott (http://vbrant.eu/user/57/identity)</option><option value="http://vbrant.eu/users/dave-roberts/openid">Dave Roberts (http://vbrant.eu/users/dave-roberts/openid)</option><option value="http://vbrant.eu/users/dimitris-koureas/openid">Dimitris Koureas (http://vbrant.eu/users/dimitris-koureas/openid)</option><option value="http://edwbaker.myopenid.com/">Edward Baker (http://edwbaker.myopenid.com)</option><option value="http://vbrant.eu/users/isa-vandevelde/openid">Isa Vandevelde (http://vbrant.eu/users/isa-vandevelde/openid)</option><option value="http://vbrant.eu/users/katherine-bouton/openid">Katherine Bouton (http://vbrant.eu/users/katherine-bouton/openid)</option><option value="http://vbrant.eu/users/laurence-livermore/openid">Laurence Livermore (http://vbrant.eu/users/laurence-livermore/openid)</option><option value="simon.rycroft.name">Simon Rycroft (simon.rycroft.name)</option><option value="http://vbrant.eu/users/vince-smith/openid">Vince Smith (http://vbrant.eu/users/vince-smith/openid)</option><option value="http://vsmithuk.myopenid.com/">Vincent Smith (http://vsmithuk.myopenid.com)</option><option value="http://vbrant.eu/users/khalid-almaini/openid">Khalid Almaini (http://vbrant.eu/users/khalid-almaini/openid)</option></select>');

      select.change(function() {
        $('#openid_url').val($(this).val());
      });

      select.css('display', 'block').insertAfter('#openid_url');
  }

  // Helper function to create the estimated time select
  function _select_estimated_time(default_value) {
    // Normalise the value
    if (default_value >= 35) {
      default_value = 35;
    } else if (default_value >= 7) {
      default_value = 7;
    } else {
      default_value = 1;
    }

    var options = {
      'Hours': 1,
      'Days': 7,
      'Weeks': 35
    };

    var out = "<p><label for='issue_estimated_hours'>Estimated time</label><select id='issue_estimated_hours' name='issue[estimated_hours]'>";
    $.each(options, function(name, value) {
      out = out + "<option value='" + value + "'";
      if (value == default_value) {
        out = out + " selected='selected'";
      }
      out = out + '>' + name + '</option>'; 
    });    
  
    out = out + '</select></p>'; 
    return out;
  }

  /*
   * Tweaks for the new issue page
   */
  function theme_new_issue() {
    $('#issue_estimated_hours').parent('p').replaceWith(_select_estimated_time());
    $('#issue_estimated_hours').css('width', '95px');
/*
    var date = new Date();
    date.setDate(date.getDate() + 7);

    var str = date.getFullYear() + '-' + ('0' + (date.getMonth()+1)).substr(-2,2) + '-' + ('0' + date.getDate()).substr(-2,2);
    $('#issue_due_date').val(str);
*/
    monitor('#issue_estimated_hours', 'select', theme_issue_show);
  }

  /*
   * Tweaks for the show issue page
   */
  function theme_issue_show() {
    var current_value = $('#issue_estimated_hours').val();
    $('#issue_estimated_hours').parent('p').replaceWith(_select_estimated_time(current_value));
    $('#issue_estimated_hours').css('width', '95px');
    $('body.action-show #content table.attributes tr td').each(function() {
      console.log($(this).html());
      var val = $(this).html();
      if (val.substring(0, 7) == 'http://') {
        $(this).html('<a href="' + val + '">' + val + '</a>');
      }
    });
  }

  /*
   * Tweaks when displayed in iframe from scratchpads.eu
   */
  function in_iframe() {
    $('#header').css('display', 'none');
    $('#top-menu').css('display', 'none');
    $('#sidebar').css('display', 'none');
    $('#footer').css('display', 'none');
    $('#wrapper').css('margin', 0);
    $('#content').css('width', '100%');
    $('#content div.autoscroll').nextAll().css('display', 'none');
    $('table#browser td.age, table#browser td.author, table#browser td.size').css('display', 'none');
    $('table#browser thead tr').html('<th>Name</th><th>Revision</th><th>Comment</th>');
    $('body').css('min-width', 0).css('width', '660px').css('background', '#FFF');
  }

  /*
   * Startup
   */
  $(document).ready(function() {
    if ($('body').hasClass('controller-issues') && $('body').hasClass('action-index')) {
      theme_issue_list();
    }
    if ($('body').hasClass('controller-account') && $('body').hasClass('action-login')) {
      theme_login_page();
    }
    if ($('body').hasClass('controller-issues') && $('body').hasClass('action-new')) {
      monitor('#issue_estimated_hours', 'select', theme_issue_show);
      //theme_new_issue();
      //$('#watchers_form input[checked="checked"]').parent('label').css('display', 'inline');
    }
    if ($('body').hasClass('controller-issues') && $('body').hasClass('action-show')) {
      monitor('#issue_estimated_hours', 'select', theme_issue_show);
    }
    if (window.location != window.parent.location /* && window.parent.location.host == 'scratchpads.eu' */) {
      in_iframe();
    }
    $('#support-new-issue').remove().prependTo('#sidebar');
  });
})(jQuery);
